export interface AuthResponse {
  message: string;
  token: string;
}
